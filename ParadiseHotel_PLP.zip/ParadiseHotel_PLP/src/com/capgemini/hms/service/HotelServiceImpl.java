package com.capgemini.hms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hms.dao.IHotelDao;
import com.capgemini.hms.entities.BookingDetails;
import com.capgemini.hms.entities.Hotel;
import com.capgemini.hms.entities.RoomDetails;
import com.capgemini.hms.entities.Users;
import com.capgemini.hms.exception.HotelException;

@Transactional
@Service("hotelService")
public class HotelServiceImpl implements IHotelService 
{
	
	@Autowired
	private IHotelDao hotelDao;
	
	
	
	public HotelServiceImpl() 
	{
		super();
		
	}
	
	

	public HotelServiceImpl(IHotelDao hotelDao) {
		super();
		this.hotelDao = hotelDao;
	}



	public IHotelDao getHotelDao() {
		return hotelDao;
	}



	public void setHotelDao(IHotelDao hotelDao) {
		this.hotelDao = hotelDao;
	}



	@Override
	public int addHotel(Hotel hotel) throws HotelException {
		
		return hotelDao.addHotel(hotel);
	}

	@Override
	public List<Hotel> showAllHotels() throws HotelException {
		
		return hotelDao.showAllHotels();
	}

	@Override
	public void updateHotels(Hotel hotel) throws HotelException {
		hotelDao.updateHotels(hotel);

	}

	@Override
	public List<Hotel> searchHotels(String city) throws HotelException {
		
		return hotelDao.searchHotels(city);
	}

	@Override
	public void removeHotel(String hotelId) throws HotelException {
		hotelDao.removeHotel(hotelId);

	}

	@Override
	public Hotel getHotelDetails(String hotelId) throws HotelException {
		
		return hotelDao.getHotelDetails(hotelId);
	}

	@Override
	public int addRoomDetails(RoomDetails room) throws HotelException {
		
		return hotelDao.addRoomDetails(room);
	}

	@Override
	public void updateRoomDetails(RoomDetails room) throws HotelException {
		hotelDao.updateRoomDetails(room);

	}

	@Override
	public RoomDetails getRoomDetails(String roomId) throws HotelException {
		
		return hotelDao.getRoomDetails(roomId);
	}

	@Override
	public List<BookingDetails> showAllBookings() throws HotelException {
		
		return hotelDao.showAllBookings();
	}

	@Override
	public int addBookingDetails(BookingDetails book) throws HotelException {
		
		return hotelDao.addBookingDetails(book);
	}

	@Override
	public void removeBooking(String bookingId) throws HotelException {
		hotelDao.removeBooking(bookingId);

	}

	@Override
	public boolean isUserExist(String unm) throws HotelException {
		
		return hotelDao.isUserExist(unm);
	}

	@Override
	public int addUSer(Users user) throws HotelException {
		
		return hotelDao.addUSer(user);
	}

	@Override
	public List<Users> showAll() throws HotelException {
		
		return hotelDao.showAll();
	}

	@Override
	public Users getUserDetails(String username,String pass) throws HotelException{
		
		return hotelDao.getUserDetails(username, pass);
	}

	@Override
	public void updateUserDetails(Users user) throws HotelException {
		hotelDao.updateUserDetails(user);

	}

}
