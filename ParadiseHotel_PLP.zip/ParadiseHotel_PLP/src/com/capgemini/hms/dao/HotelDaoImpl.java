package com.capgemini.hms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.hms.entities.BookingDetails;
import com.capgemini.hms.entities.Hotel;
import com.capgemini.hms.entities.RoomDetails;
import com.capgemini.hms.entities.Users;
import com.capgemini.hms.exception.HotelException;

@Repository("hotelDAO")
public class HotelDaoImpl implements IHotelDao 
{
	@PersistenceContext
	private EntityManager entityManager;
	
	public HotelDaoImpl() 
	{
		super();
		
	}
	
	

	public HotelDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}
	



	public EntityManager getEntityManager() {
		return entityManager;
	}



	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}



	@Override
	public int addHotel(Hotel hotel) throws HotelException 
	{
		
		int hotelId=0;
		try{
		
			entityManager.persist(hotel);
			hotelId=hotel.getHotelId();
			
		}
		catch(Exception e)
		{
			
			throw new HotelException(e.getMessage());
		}
		return hotelId;
	}

	@Override
	public List<Hotel> showAllHotels() throws HotelException 
	{
	
		List<Hotel> hotels=null;
		try{
			
			
			TypedQuery<Hotel> tQuery=entityManager.createNamedQuery("ShowAllHotels",Hotel.class);
			hotels=tQuery.getResultList();
			
			
		
			
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}
		if(hotels==null || hotels.isEmpty())
			throw new HotelException("No Hotels to display");
		return hotels;
	}

	@Override
	public void updateHotels(Hotel hotel) throws HotelException 
	{
		try{
			
			
			entityManager.merge(hotel);
			entityManager.flush();
			
		
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public List<Hotel> searchHotels(String city) throws HotelException 
	{
	
		List<Hotel> hotels=null;
		try{
					
				
					
					TypedQuery<Hotel> tQuery=entityManager.createQuery("select h from Hotelplp h where h.city=:hcity",Hotel.class);
					tQuery.setParameter("hcity", city);
					hotels=tQuery.getResultList();
					
				
					
				}
				catch(Exception e)
				{
					
					throw new HotelException(e.getMessage());
				}
				return hotels;
	}

	@Override
	public void removeHotel(String hotelId) throws HotelException 
	{
		
		try{
			
			
			Hotel hotel=entityManager.find(Hotel.class, hotelId);
			entityManager.remove(hotel);
			
		
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public Hotel getHotelDetails(String hotelId) throws HotelException
	{
		
		Hotel hotel=null;
		try{
				
			
				hotel=entityManager.find(Hotel.class,hotelId);
				//entityManager.flush();
				
			
			}
			catch(Exception e)
			{
				
				throw new HotelException(e.getMessage());
			}
			if(hotel==null)
			{
				throw new HotelException("No Hotel found with id="+hotelId);
			}
		
			return hotel;
	}

	@Override
	public int addRoomDetails(RoomDetails room) throws HotelException 
	{
		
		int roomId=0;
		try{
		
			entityManager.persist(room);
			roomId=room.getRoomId();
			
		}
		catch(Exception e)
		{
			
			throw new HotelException(e.getMessage());
		}
		return roomId;
	}

	@Override
	public void updateRoomDetails(RoomDetails room) throws HotelException 
	{
		try{
			
			
			entityManager.merge(room);
			entityManager.flush();
			
		
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}

	}

	@Override
	public RoomDetails getRoomDetails(String roomId) throws HotelException 
	{
		
		RoomDetails room=null;
		try{
				
			
				room=entityManager.find(RoomDetails.class,roomId);
				entityManager.flush();
				
			
			}
			catch(Exception e)
			{
				
				throw new HotelException(e.getMessage());
			}
			if(room==null)
			{
				throw new HotelException("No Room found with id="+roomId);
			}
		
			return room;
	}

	@Override
	public List<BookingDetails> showAllBookings() throws HotelException 
	{
		
		List<BookingDetails> bookingDetails=null;
		try{
			
			
			TypedQuery<BookingDetails> tQuery=entityManager.createNamedQuery("ShowAllBookings",BookingDetails.class);
			bookingDetails=tQuery.getResultList();
			
			
		
			
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}
		if(bookingDetails==null || bookingDetails.isEmpty())
			throw new HotelException("No Bookings to display");
		return bookingDetails;
	}

	@Override
	public int addBookingDetails(BookingDetails book) throws HotelException 
	{
		
		int bookId=0;
		try{
		
			entityManager.persist(book);
			bookId=book.getBookId();
			
		}
		catch(Exception e)
		{
			
			throw new HotelException(e.getMessage());
		}
		return bookId;
	}

	@Override
	public void removeBooking(String bookingId) throws HotelException 
	{
		try{
			
			
			BookingDetails bookingDetails=entityManager.find(BookingDetails.class, bookingId);
			entityManager.remove(bookingDetails);
			
		
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}


	}

	@Override
	public boolean isUserExist(String unm) throws HotelException 
	{
		boolean flag=false;
		Users user=null;
		try 
		{
			user=entityManager.find(Users.class, unm);
			if(user!=null)
			{
				flag=true;
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		return flag;
	}

	@Override
	public int addUSer(Users user) throws HotelException 
	{
		
		int userId=0;
		try{
		
			entityManager.persist(user);
			userId=user.getUserId();
			
		}
		catch(Exception e)
		{
			
			throw new HotelException(e.getMessage());
		}
		return userId;
	}

	@Override
	public List<Users> showAll() throws HotelException 
	{
		
		List<Users> users=null;
		try{
			
			
			TypedQuery<Users> tQuery=entityManager.createNamedQuery("ShowAllUsers",Users.class);
			users=tQuery.getResultList();
			
			
		
			
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}
		if(users==null || users.isEmpty())
			throw new HotelException("No Bookings to display");
		return users;
	}

	@Override
	public Users getUserDetails(String username,String pass) throws HotelException
	{
		
		Users user=null;
		try{
				
			
				user=entityManager.find(Users.class,username);
				user=entityManager.find(Users.class,pass);
				entityManager.flush();
				
			
			}
			catch(Exception e)
			{
				
				throw new HotelException(e.getMessage());
			}
			if(user==null)
			{
				throw new HotelException("No User found with username="+username);
			}
		
			return user;
	}

	@Override
	public void updateUserDetails(Users user) throws HotelException 
	{
		
		try{
			
			
			entityManager.merge(user);
			entityManager.flush();
			
		
		}
		catch(Exception e)
		{
		
			throw new HotelException(e.getMessage());
		}

	}

}
