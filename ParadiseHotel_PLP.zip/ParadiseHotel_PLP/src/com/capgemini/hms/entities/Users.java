package com.capgemini.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Usersplp")
/*@NamedQueries(
		@NamedQuery(name="ShowAllUsers",query="select u from Usersplp u")
		)*/
public class Users
{

/*	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseqgenuser")
	@SequenceGenerator(name="myseqgenuser", sequenceName="userId_seq", initialValue=1000)*/
	@Column(name="room_id")
	private int  userId;
	
	@NotEmpty(message="password cannot be empty")
	@Column(name="password", nullable = false)
	private  String password;
	
	@NotEmpty(message="Role cannot be empty")
	@Column(name="role", nullable = false)
	private String role;
	
	  
	@Id
	@NotEmpty(message="User Name cannot be empty")
	@Column(name="user_name", nullable = false)
	private String username;
	
	@NotEmpty(message="mobile no no Id cannot be empty")
	@Column(name="mobile_no", nullable = false)
	private  String mobileNo;
	
	@NotEmpty(message="phone no Id cannot be empty")
	@Column(name="phone", nullable = false)
	private String phoneNo;
	
	@NotEmpty(message="address Id cannot be empty")
	@Column(name="address", nullable = false)
	private String address;
	
	@NotEmpty(message="email Id cannot be empty")
	@Column(name="email", nullable = false)
	private String email;
  
/*  create table Usersplp(user_id varchar2(4) primary key, password varchar2(7), role varchar(10), 
		  user_name varchar2(20), mobile_no varchar2(10), phone varchar2(10), address varchar2(25), email  varchar2(30));*/
  
public Users() 
{
	super();
}

public Users(int userId, String password, String role, String username,
		String mobileNo, String phoneNo, String address, String email) {
	super();
	this.userId = userId;
	this.password = password;
	this.role = role;
	this.username = username;
	this.mobileNo = mobileNo;
	this.phoneNo = phoneNo;
	this.address = address;
	this.email = email;
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getMobileNo() {
	return mobileNo;
}

public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}

public String getPhoneNo() {
	return phoneNo;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Override
public String toString() {
	return "User [userId=" + userId + ", password=" + password + ", role="
			+ role + ", username=" + username + ", mobileNo=" + mobileNo
			+ ", phoneNo=" + phoneNo + ", address=" + address + ", email="
			+ email + "]";
}
  

}
