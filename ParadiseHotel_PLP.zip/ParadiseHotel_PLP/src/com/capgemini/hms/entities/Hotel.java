package com.capgemini.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Hotelplp")
/*@NamedQueries(
		@NamedQuery(name="ShowAllHotels",query="select h from Hotelplp h")
		)*/
public class Hotel
{
/*	ii.	Hotel: hotel_id(varchar(4)), city (varchar(10)), hotel_name(varchar (20)), address(varchar(25)), 
	description varchar(50)), avg_rate_per-night (number(m,n)), 
	phone_no1(varchar(10)), phone_no2(varchar(10)), rating(varchar(4)), email (varchar(15)), fax (varchar(15))
	*/
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseqgenhotel")
	@SequenceGenerator(name="myseqgenhotel", sequenceName="hotelId_seq", initialValue=1000)
	@Column(name="hotel_id")
	private int hotelId;
	
	@NotEmpty(message="City cannot be empty")
	@Column(name="city", nullable = false)
	private String city;
	
	@NotEmpty(message="Hotel Name cannot be empty")
	@Column(name="hotel_name", nullable = false)
	private String hotelName;
	
	@NotEmpty(message="address Name cannot be empty")
	@Column(name="address", nullable = false)
	private String address;
	
	@NotEmpty(message="description Name cannot be empty")
	@Column(name="description", nullable = false)
	private String description;
	
	@NotEmpty(message="Rate cannot be empty")
	@Column(name="avg_rate_per-night", nullable = false)
	private float avgRatePerNight;
	
	@NotEmpty(message="Phone no Name cannot be empty")
	@Column(name="phone_no1", nullable = false)
	private String phoneNo1;
	
	@NotEmpty(message="Phone Name cannot be empty")
	@Column(name="phone_no2", nullable = false)
	private String phoneNo2;
	
	@NotEmpty(message="Rating cannot be empty")
	@Column(name="rating", nullable = false)
	private String rating;
	
	@NotEmpty(message="Email cannot be empty")
	@Column(name="email", nullable = false)
	private String email;
	
	@NotEmpty(message="Fax cannot be empty")
	@Column(name="fax", nullable = false)
	private String fax;
	
	
	public Hotel() {
		super();
	}


	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", avgRatePerNight=" + avgRatePerNight
				+ ", phoneNo1=" + phoneNo1 + ", phoneNo2=" + phoneNo2
				+ ", rating=" + rating + ", email=" + email + ", fax=" + fax
				+ "]";
	}


	public int getHotelId() {
		return hotelId;
	}


	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getHotelName() {
		return hotelName;
	}


	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public float getAvgRatePerNight() {
		return avgRatePerNight;
	}


	public void setAvgRatePerNight(float avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}


	public String getPhoneNo1() {
		return phoneNo1;
	}


	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}


	public String getPhoneNo2() {
		return phoneNo2;
	}


	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getFax() {
		return fax;
	}


	public void setFax(String fax) {
		this.fax = fax;
	}


	public Hotel(int hotelId, String city, String hotelName, String address,
			String description, float avgRatePerNight, String phoneNo1,
			String phoneNo2, String rating, String email, String fax) {
		super();
		this.hotelId = hotelId;
		this.city = city;
		this.hotelName = hotelName;
		this.address = address;
		this.description = description;
		this.avgRatePerNight = avgRatePerNight;
		this.phoneNo1 = phoneNo1;
		this.phoneNo2 = phoneNo2;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}
	
	
}
