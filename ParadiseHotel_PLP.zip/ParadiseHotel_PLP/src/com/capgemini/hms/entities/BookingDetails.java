package com.capgemini.hms.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;




/*BookingDetails: booking_id(varchar(4)), room_id(varchar(4)),  user_id(varchar(4)), 
booked_from (date), booked_to(date), no_of_adults, no_of_children, amount(number(6,2))
*/
@Entity
@Table(name="BookingDetailsplp")
/*@NamedQueries(
		@NamedQuery(name="ShowAllBookings",query="select b from BookingDetailsplp b")
		)*/
public class BookingDetails 
{
 
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseqgenbooking")
	@SequenceGenerator(name="myseqgenbooking", sequenceName="bookingId_seq", initialValue=1000)
	@Column(name="booking_id")
	private int bookId;
	
	@NotEmpty(message="Room Id cannot be empty")
	@Column(name="room_id", nullable = false)
	private int roomId;
	
	@NotEmpty(message="User Id cannot be empty")
	@Column(name="user_id", nullable = false)
	private int userId;
	
	@NotEmpty(message="Date cannot be empty")
	@Column(name="booked_from", nullable = false)
	private Date bookedFrom;
	
	@NotEmpty(message="Date cannot be empty")
	@Column(name="booked_to", nullable = false)
	private Date bookedTo;
 
	@NotEmpty(message="No Of Adults cannot be empty")
	@Column(name="no_of_adults", nullable = false)
	@Min(value=1)
	@Max(value=3)
	private  int noOfAdults;
	
	@Max(value=3)
	@Column(name="no_of_children")
	private int  noOfChildren;
	
	@NotEmpty(message="Amount cannot be empty")
	@Column(name="amount", nullable = false)
	private float amount;
 
public BookingDetails()
{
	super();
}

public BookingDetails(int bookId, int roomId, int userId,
		Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChildren,
		float amount) {
	super();
	this.bookId = bookId;
	this.roomId = roomId;
	this.userId = userId;
	this.bookedFrom = bookedFrom;
	this.bookedTo = bookedTo;
	this.noOfAdults = noOfAdults;
	this.noOfChildren = noOfChildren;
	this.amount = amount;
}

public int getBookId() {
	return bookId;
}

public void setBookId(int bookId) {
	this.bookId = bookId;
}

public int getRoomId() {
	return roomId;
}

public void setRoomId(int roomId) {
	this.roomId = roomId;
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public Date getBookedFrom() {
	return bookedFrom;
}

public void setBookedFrom(Date bookedFrom) {
	this.bookedFrom = bookedFrom;
}

public Date getBookedTo() {
	return bookedTo;
}

public void setBookedTo(Date bookedTo) {
	this.bookedTo = bookedTo;
}

public int getNoOfAdults() {
	return noOfAdults;
}

public void setNoOfAdults(int noOfAdults) {
	this.noOfAdults = noOfAdults;
}

public int getNoOfChildren() {
	return noOfChildren;
}

public void setNoOfChildren(int noOfChildren) {
	this.noOfChildren = noOfChildren;
}

public float getAmount() {
	return amount;
}

public void setAmount(float amount) {
	this.amount = amount;
}

@Override
public String toString()
{
	return "BookingDetails [bookId=" + bookId + ", roomId=" + roomId
			+ ", userId=" + userId + ", bookedFrom=" + bookedFrom
			+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
			+ ", noOfChildren=" + noOfChildren + ", amount=" + amount + "]";
}
 
 
 
 
	
}
