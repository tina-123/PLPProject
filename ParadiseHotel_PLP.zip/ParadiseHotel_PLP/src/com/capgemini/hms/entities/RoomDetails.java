package com.capgemini.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


/*RoomDetails: hotel_id(varchar(4)),  room_id (varchar(4)),  room_no(varchar(3)),
room_type(varchar(20)), per_night_rate (number(6,2)), availability (Boolean), photo (blob))*/

@Entity
@Table(name="RoomDetailsplp")
public class RoomDetails
{
	@NotEmpty(message="Hotel Id cannot be empty")
	@Column(name="hotel_id", nullable = false)
	private int hotelId;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseqgenroom")
	@SequenceGenerator(name="myseqgenroom", sequenceName="roomId_seq", initialValue=1000)
	@Column(name="room_id")
	private int roomId;
	
	@NotEmpty(message="Room no cannot be empty")
	@Column(name="room_no", nullable = false)
	private String roomNo;
	
	@NotEmpty(message="room type cannot be empty")
	@Column(name="room_type", nullable = false)
	private String roomType;
	
	@NotEmpty(message="Rate cannot be empty")
	@Column(name="per_night_rate", nullable = false)
	private float perNightRate;
	
	@NotEmpty(message="availability cannot be empty")
	@Column(name="availability", nullable = false)
	private String availability;
	
	@NotEmpty(message="Description cannot be empty")
	@Column(name="photo", nullable = false)
	private String photo;
	
	
	public RoomDetails() 
	{
		super();
	}


	public RoomDetails(int hotelId, int roomId, String roomNo,
			String roomType, float perNightRate, String availability,
			String photo) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.availability = availability;
		this.photo = photo;
	}


	public int getHotelId() {
		return hotelId;
	}


	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}


	public int getRoomId() {
		return roomId;
	}


	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}


	public String getRoomNo() {
		return roomNo;
	}


	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}


	public String getRoomType() {
		return roomType;
	}


	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}


	public float getPerNightRate() {
		return perNightRate;
	}


	public void setPerNightRate(float perNightRate) {
		this.perNightRate = perNightRate;
	}


	public String getAvailability() {
		return availability;
	}


	public void setAvailability(String availability) {
		this.availability = availability;
	}


	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


	@Override
	public String toString() {
		return "RoomDetails [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + ", photo=" + photo + "]";
	}
	
}
