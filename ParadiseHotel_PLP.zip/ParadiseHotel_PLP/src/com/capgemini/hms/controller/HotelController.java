package com.capgemini.hms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.hms.entities.Users;
import com.capgemini.hms.service.IHotelService;

@Controller
public class HotelController 
{
	@Autowired
   IHotelService hotelService;

	public HotelController()
	{
		super();
	}

	public HotelController(IHotelService hotelService) {
		super();
		this.hotelService = hotelService;
	}

	public IHotelService getHotelService() {
		return hotelService;
	}

	public void setHotelService(IHotelService hotelService) {
		this.hotelService = hotelService;
	}
	
	@RequestMapping("loginUser")
	public String validateUser(@RequestParam("txtUnm")String username,@RequestParam("txtPwd")String password)
	{
		String  homepage="";
		try{
		if(hotelService.isUserExist(username))
		{
			Users user=hotelService.getUserDetails(username, password);
			System.out.println(user);
			if(username.equals(user.getUsername())&&password.equals(user.getPassword()))
			{
				if(user.getRole().equalsIgnoreCase("admin"))
					homepage="AdminIndex";
			}
			else
			{
				if(user.getRole().equalsIgnoreCase("user")||user.getRole().equalsIgnoreCase("employee"))
					homepage="UserHome";
			}
					
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return homepage;
	}
	
}
